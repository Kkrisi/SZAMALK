/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package esemenyvezerles;

import javax.swing.JRootPane;

/**
 *
 * @author KádárKristófPéter(SZ
 */
class JOpionPane {

    static void showMessageDialog(JRootPane rootPane, String uzenet) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
